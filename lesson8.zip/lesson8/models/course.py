


class Course:
    def __init__(self, name : str, teacher_id):
        self.name = name 
        self.teacher_id = teacher_id