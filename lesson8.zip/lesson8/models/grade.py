

class Grade:
    def __init__(self, student_id : int, course_id : int, grade : float):
        self.student_id = student_id
        self.course_id = course_id
        self.grade = grade